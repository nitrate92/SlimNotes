﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Media;
using System.IO;
//remove unused namespaces when done

namespace SlimNotes_CSharp
{
    public partial class Mainnote : Form
    {
        public Mainnote()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Console.WriteLine("Form loaded.");
        }

        private void ClearConsoleOutputToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Console.Clear();
        }

        private void ContextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            //sound that plays when the menu is opened
            SoundPlayer audio = new SoundPlayer(SlimNotes_CSharp.Properties.Resources.boopsfx1);
            audio.Play();
            Console.WriteLine("boopsfx1 played.");
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
            Console.WriteLine("Cut.");
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
            Console.WriteLine("Copy.");
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
            Console.WriteLine("Paste.");
        }

        private void YellowDefaultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.BackColor = Color.Yellow;
            Console.WriteLine("Note color changed to yellow.");
        }

        private void OrangeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.BackColor = Color.Orange;
            Console.WriteLine("Note color changed to orange.");
        }

        private void BlueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.BackColor = Color.LightBlue;
            Console.WriteLine("Note color changed to blue.");
        }

        private void WhiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.BackColor = Color.White;
            Console.WriteLine("Note color changed to white.");
        }

        private void CustomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
                richTextBox1.BackColor = colorDialog1.Color;
            Console.WriteLine("Note color changed to a custom color.");
        }

        private void FontsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //opens the font change dialog and sets it
            fontDialog1.ShowColor = true;
            fontDialog1.Font = richTextBox1.Font;
            fontDialog1.Color = richTextBox1.ForeColor;
            if (fontDialog1.ShowDialog() != DialogResult.Cancel)
            {
                richTextBox1.Font = fontDialog1.Font;
                richTextBox1.ForeColor = fontDialog1.Color;
                Console.WriteLine("Font changed.");
            }
        }

        private void NewNoteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //poor way of handling the creation of a new note because if the first note is closed, ALL OF THEM CLOSE
            //Mainnote newForm = new Mainnote();
            //newForm.Show();
            //Program.Poop();
            Console.WriteLine("New note window created. big fat fucking reminder that i removed the code from program.cs for this");
        }

        private void OpenToolStripMenuItem_Click(object sender, EventArgs e)
        {

            {
                //i hate my life
                //var fileContent = string.Empty;
                //var filePath = string.Empty;
                //if (openFileDialog1.ShowDialog() == DialogResult.OK)
                //{
                //    richTextBox1.Text = fileContent;
                    
                //}
            }
        }
    }
}
